-- Insert Default Products
INSERT INTO Products (name, description, image_url, price, category_id, featured) 
VALUES ('GeForce RTX 4090', 'The latest graphics card', 'images/rtx4090.jpg', 1499.99, 1, 1);

INSERT INTO Products (name, description, image_url, price, category_id, featured) 
VALUES ('Gaming Keyboard', 'RGB Mechanical Keyboard', 'images/gprokeyboard.png', 99.99, 2, 0);

INSERT INTO Products (name, description, image_url, price, category_id, featured) 
VALUES ('Gaming Mouse', 'Lightweight precision mouse', 'images/gpromouse.png', 59.99, 3, 0);
