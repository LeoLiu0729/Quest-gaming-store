-- Drop CartProducts Table
DROP TABLE IF EXISTS CartProducts;

-- Drop Carts Table
DROP TABLE IF EXISTS Carts;

-- Drop Products Table
DROP TABLE IF EXISTS Products;

-- Drop Categories Table
DROP TABLE IF EXISTS Categories;

-- Drop Users Table
DROP TABLE IF EXISTS Users;
