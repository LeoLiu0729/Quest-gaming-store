-- Insert Default Categories
INSERT INTO Categories (name, priority_level) VALUES ('Graphics Cards', 1);
INSERT INTO Categories (name, priority_level) VALUES ('Keyboards', 2);
INSERT INTO Categories (name, priority_level) VALUES ('Mice', 3);
